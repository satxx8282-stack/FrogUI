package dev.blod.client.module.impl;

import dev.blod.client.event.Subscribe;
import dev.blod.client.event.TickEvent;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

/** Tells the server you are on the ground while falling, so you take no fall damage. */
public final class NoFall extends Module {
    public NoFall() {
        super("NoFall", "No fall damage.", Category.PLAYER, -1);
    }

    @Subscribe
    public void onTick(TickEvent e) {
        ClientPlayerEntity p = mc.player;
        if (p == null || p.isOnGround() || p.isFallFlying() || p.getAbilities().allowFlying) return;
        if (p.fallDistance > 2.5f) p.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, p.horizontalCollision));
    }
}
