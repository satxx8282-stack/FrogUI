package dev.blod.client.mixin;

import dev.blod.client.BlodClient;
import dev.blod.client.module.impl.ESP;
import dev.blod.client.module.impl.FreeCam;
import dev.blod.client.module.impl.FreeLook;
import dev.blod.client.module.impl.Hitbox;
import dev.blod.client.module.impl.Zoom;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * - Redirects mouse look for FreeCam / FreeLook (the real player rotation is never changed).
 * - Scales mouse look while zoomed.
 * - ESP: makes selected entities glow through walls.
 */
@Mixin(Entity.class)
public abstract class EntityMixin {

    private boolean blod$isLocalPlayer() {
        return (Object) this == MinecraftClient.getInstance().player;
    }

    // ---------- look ----------
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void blod$look(double dx, double dy, CallbackInfo ci) {
        if (!blod$isLocalPlayer()) return;

        FreeCam fc = BlodClient.module(FreeCam.class);
        if (fc != null && fc.isEnabled()) { fc.handleLook(dx, dy); ci.cancel(); return; }

        FreeLook fl = BlodClient.module(FreeLook.class);
        if (fl != null && fl.isEnabled()) { fl.handleLook(dx, dy); ci.cancel(); }
    }

    @ModifyVariable(method = "changeLookDirection", at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private double blod$zoomX(double dx) {
        Zoom z = BlodClient.module(Zoom.class);
        return z != null && blod$isLocalPlayer() ? z.scaleLook(dx) : dx;
    }

    @ModifyVariable(method = "changeLookDirection", at = @At("HEAD"), argsOnly = true, ordinal = 1)
    private double blod$zoomY(double dy) {
        Zoom z = BlodClient.module(Zoom.class);
        return z != null && blod$isLocalPlayer() ? z.scaleLook(dy) : dy;
    }

    // ---------- ESP ----------
    @Inject(method = "isGlowing", at = @At("RETURN"), cancellable = true)
    private void blod$glow(CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValueZ()) return;
        ESP esp = BlodClient.module(ESP.class);
        if (esp != null && esp.shouldGlow((Entity) (Object) this)) cir.setReturnValue(true);
    }

    @Inject(method = "getTeamColorValue", at = @At("RETURN"), cancellable = true)
    private void blod$glowColor(CallbackInfoReturnable<Integer> cir) {
        ESP esp = BlodClient.module(ESP.class);
        if (esp != null && esp.shouldGlow((Entity) (Object) this)) cir.setReturnValue(esp.color((Entity) (Object) this));
    }

    // ---------- Hitbox ----------
    @Inject(method = "getTargetingMargin", at = @At("RETURN"), cancellable = true, require = 0)
    private void blod$hitbox(CallbackInfoReturnable<Float> cir) {
        Hitbox h = BlodClient.module(Hitbox.class);
        if (h != null && h.isEnabled()) cir.setReturnValue(cir.getReturnValueF() + h.expandFor((Entity) (Object) this));
    }
}
