package dev.blod.client.module.impl;

import dev.blod.client.command.CommandHandler;
import dev.blod.client.event.MouseButtonEvent;
import dev.blod.client.event.Subscribe;
import dev.blod.client.friend.FriendManager;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/** Middle-click a player to add / remove them as friend. */
public final class MiddleClickFriend extends Module {
    public MiddleClickFriend() {
        super("MiddleClickFriend", "Middle click a player to (un)friend.", Category.PLAYER, -1);
    }

    @Subscribe
    public void onMouse(MouseButtonEvent e) {
        if (e.button() != 2 || e.action() != 1 || mc.player == null) return;
        if (mc.crosshairTarget == null || mc.crosshairTarget.getType() != HitResult.Type.ENTITY) return;
        if (!(((EntityHitResult) mc.crosshairTarget).getEntity() instanceof PlayerEntity pl)) return;

        String name = pl.getName().getString();
        boolean added = FriendManager.toggle(name);
        CommandHandler.reply((added ? "Added friend " : "Removed friend ") + name);
    }
}
