package dev.blod.client.module.impl;

import dev.blod.client.BlodClient;
import dev.blod.client.event.Render2DEvent;
import dev.blod.client.event.Subscribe;
import dev.blod.client.gui.RenderUtil;
import dev.blod.client.gui.Theme;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.util.CombatTracker;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

/** Panel with name / health / distance of the KillAura target, the last entity you hit, or what you look at. */
public final class TargetHud extends Module {
    private float shownHealth = -1;

    public TargetHud() {
        super("TargetHud", "Shows info about your current target.", Category.CLIENT, -1);
        setListed(false);
    }

    private LivingEntity pickTarget() {
        KillAura ka = BlodClient.module(KillAura.class);
        if (ka != null && ka.isEnabled() && ka.getTarget() != null) return ka.getTarget();
        LivingEntity last = CombatTracker.getLast();
        if (last != null) return last;
        if (mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY
                && ((EntityHitResult) mc.crosshairTarget).getEntity() instanceof LivingEntity le) return le;
        return null;
    }

    @Subscribe
    public void onRender2D(Render2DEvent e) {
        if (mc.player == null) return;
        LivingEntity t = pickTarget();
        if (t == null) { shownHealth = -1; return; }

        DrawContext ctx = e.context();
        TextRenderer tr = mc.textRenderer;
        float max = Math.max(1f, t.getMaxHealth()), hp = Math.max(0f, t.getHealth());
        shownHealth = shownHealth < 0 ? hp : shownHealth + (hp - shownHealth) * 0.15f;

        int w = 146, h = 38;
        int x = ctx.getScaledWindowWidth() / 2 + 26, y = ctx.getScaledWindowHeight() / 2 + 26;

        RenderUtil.roundedOutline(ctx, x, y, w, h, 5, Theme.alpha(Theme.DARK_RED, 220), Theme.alpha(Theme.BG, 225));
        ctx.fill(x + 1, y + 5, x + 3, y + h - 5, Theme.RED);

        RenderUtil.text(ctx, tr, t.getName().getString(), x + 9, y + 6, 0xFFFFFFFF, true);
        String info = String.format("%.1f HP  |  %.1fm", hp, mc.player.distanceTo(t));
        RenderUtil.text(ctx, tr, info, x + 9, y + 18, Theme.TEXT_DIM, true);

        int bx = x + 9, by = y + h - 9, bw = w - 18;
        ctx.fill(bx, by, bx + bw, by + 4, 0xFF1E1E1E);
        int fill = (int) (bw * Math.min(1f, shownHealth / max));
        ctx.fill(bx, by, bx + fill, by + 4, Theme.lerp(Theme.BRIGHT_RED, Theme.DARK_RED, 1f - Math.min(1f, shownHealth / max)));
    }
}
