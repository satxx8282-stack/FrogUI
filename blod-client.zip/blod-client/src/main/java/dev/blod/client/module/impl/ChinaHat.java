package dev.blod.client.module.impl;

import dev.blod.client.event.Render2DEvent;
import dev.blod.client.event.Subscribe;
import dev.blod.client.gui.Projection;
import dev.blod.client.gui.RenderUtil;
import dev.blod.client.gui.Theme;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.NumberSetting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Vec3d;

/** A glowing red cone above your head (visible in third person / FreeCam / FreeLook). */
public final class ChinaHat extends Module {
    private final NumberSetting radius = add(new NumberSetting("Radius", 0.6, 0.3, 1.2, 0.05));
    private final NumberSetting heightS = add(new NumberSetting("Height", 0.35, 0.15, 0.8, 0.05));

    public ChinaHat() {
        super("ChinaHat", "Draws a hat on your head.", Category.RENDER, -1);
    }

    @Subscribe
    public void onRender2D(Render2DEvent ev) {
        if (mc.player == null || mc.options.getPerspective().isFirstPerson() && !dev.blod.client.BlodClient.module(FreeCam.class).isEnabled()) return;
        DrawContext ctx = ev.context();
        Vec3d base = mc.player.getLerpedPos(ev.tickDelta()).add(0, mc.player.getHeight() + 0.02, 0);
        double[] apex = Projection.project(base.add(0, heightS.get(), 0), ev.tickDelta());

        int n = 28;
        double[] prev = null, first = null;
        double t = System.currentTimeMillis() / 600.0;
        for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2 / n;
            double[] p = Projection.project(base.add(Math.cos(a) * radius.get(), 0, Math.sin(a) * radius.get()), ev.tickDelta());
            int c = Theme.lerp(Theme.RED, Theme.DARK_RED, (float) (0.5 + 0.5 * Math.sin(t + i * 0.4)));
            if (p != null) {
                if (apex != null && i % 2 == 0) RenderUtil.line(ctx, apex[0], apex[1], p[0], p[1], Theme.alpha(c, 150));
                if (prev != null) RenderUtil.line(ctx, prev[0], prev[1], p[0], p[1], c);
            }
            if (i == 0) first = p;
            prev = p;
        }
        if (prev != null && first != null) RenderUtil.line(ctx, prev[0], prev[1], first[0], first[1], Theme.RED);
    }
}
