package dev.blod.client.module.impl;

import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.ModeSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Vec3d;

/**
 * Turns normal hits into critical hits. Called from ClientPlayerInteractionManagerMixin right before an attack.
 *  Packet: tells the server you briefly left the ground.
 *  Jump:   gives you a small upward velocity.
 */
public final class Criticals extends Module {
    private final ModeSetting mode = add(new ModeSetting("Mode", "Packet", "Packet", "Jump"));

    public Criticals() {
        super("Criticals", "Every hit is a critical hit.", Category.COMBAT, -1);
    }

    public void onAttack(Entity target) {
        ClientPlayerEntity p = mc.player;
        if (p == null || !p.isOnGround() || p.isTouchingWater() || p.isInLava() || p.hasVehicle() || p.isClimbing()) return;

        if (mode.is("Jump")) {
            Vec3d v = p.getVelocity();
            p.setVelocity(v.x, 0.42, v.z);
        } else {
            double x = p.getX(), y = p.getY(), z = p.getZ();
            boolean hc = p.horizontalCollision;
            p.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y + 0.0625, z, false, hc));
            p.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false, hc));
        }
    }
}
