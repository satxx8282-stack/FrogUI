package dev.blod.client.module.impl;

import dev.blod.client.event.Render2DEvent;
import dev.blod.client.event.Subscribe;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

/** Armor pieces with durability bars, right of the hotbar. */
public final class ArmorHud extends Module {
    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    public ArmorHud() {
        super("ArmorHud", "Shows your armor and its durability.", Category.CLIENT, -1);
        setListed(false);
    }

    @Subscribe
    public void onRender2D(Render2DEvent e) {
        if (mc.player == null || mc.player.isSpectator()) return;
        DrawContext ctx = e.context();
        int x = ctx.getScaledWindowWidth() / 2 + 118;
        int y = ctx.getScaledWindowHeight() - 20;
        for (EquipmentSlot slot : SLOTS) {
            ItemStack stack = mc.player.getEquippedStack(slot);
            if (!stack.isEmpty()) {
                ctx.drawItem(stack, x, y);
                ctx.drawStackOverlay(mc.textRenderer, stack, x, y);
            }
            x += 18;
        }
    }
}
