package dev.blod.client.module.impl;

import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.NumberSetting;

/** Longer interaction range for the local player (PlayerEntityMixin). The server still enforces its own limit. */
public final class Reach extends Module {
    private final NumberSetting range = add(new NumberSetting("Range", 3.6, 3.0, 6.0, 0.1));

    public Reach() {
        super("Reach", "Hit entities from further away.", Category.COMBAT, -1);
    }

    public double range() { return range.get(); }
}
