package dev.blod.client.module.impl;

import dev.blod.client.event.Render2DEvent;
import dev.blod.client.event.Subscribe;
import dev.blod.client.gui.Theme;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.BoolSetting;
import dev.blod.client.module.setting.ModeSetting;
import dev.blod.client.module.setting.NumberSetting;
import net.minecraft.client.gui.DrawContext;

/** Custom crosshair that replaces the vanilla one (InGameHudMixin cancels vanilla while enabled). */
public final class CrosshairModule extends Module {
    private final ModeSetting style = add(new ModeSetting("Style", "Cross", "Cross", "Dot", "Circle"));
    private final ModeSetting color = add(new ModeSetting("Color", "Red", "Red", "White", "Dark Red"));
    private final NumberSetting size = add(new NumberSetting("Size", 5, 1, 12, 1));
    private final NumberSetting gap = add(new NumberSetting("Gap", 3, 0, 10, 1));
    private final NumberSetting thickness = add(new NumberSetting("Thickness", 1, 1, 4, 1));
    private final BoolSetting dynamic = add(new BoolSetting("Dynamic Gap", true));
    private final BoolSetting outline = add(new BoolSetting("Outline", true));

    private float dyn;

    public CrosshairModule() {
        super("Crosshair", "Custom crosshair.", Category.RENDER, -1);
        setListed(false);
    }

    private int rgb() {
        return switch (color.getValue()) {
            case "White" -> 0xFFFFFFFF;
            case "Dark Red" -> Theme.DARK_RED;
            default -> Theme.RED;
        };
    }

    private void rect(DrawContext c, int x1, int y1, int x2, int y2) {
        if (outline.get()) c.fill(x1 - 1, y1 - 1, x2 + 1, y2 + 1, 0xFF000000);
        c.fill(x1, y1, x2, y2, rgb());
    }

    @Subscribe
    public void onRender2D(Render2DEvent ev) {
        if (mc.player == null || !mc.options.getPerspective().isFirstPerson()) return;
        DrawContext ctx = ev.context();
        int cx = ctx.getScaledWindowWidth() / 2, cy = ctx.getScaledWindowHeight() / 2;
        int t = thickness.getValue().intValue(), s = size.getValue().intValue();

        boolean moving = mc.player.getVelocity().horizontalLengthSquared() > 0.003 || !mc.player.isOnGround();
        float target = dynamic.get() ? (moving ? 3f : 0f) + (mc.player.getAttackCooldownProgress(0f) < 1f ? 2f : 0f) : 0f;
        dyn += (target - dyn) * 0.25f;
        int g = gap.getValue().intValue() + Math.round(dyn);

        switch (style.getValue()) {
            case "Dot" -> rect(ctx, cx - t, cy - t, cx + t, cy + t);
            case "Circle" -> {
                int r = g + s;
                for (int deg = 0; deg < 360; deg += 6) {
                    int px = cx + (int) Math.round(Math.cos(Math.toRadians(deg)) * r);
                    int py = cy + (int) Math.round(Math.sin(Math.toRadians(deg)) * r);
                    ctx.fill(px, py, px + t, py + t, rgb());
                }
                rect(ctx, cx, cy, cx + 1, cy + 1);
            }
            default -> {
                int h = t / 2;
                rect(ctx, cx - g - s, cy - h, cx - g, cy - h + t);     // left
                rect(ctx, cx + g, cy - h, cx + g + s, cy - h + t);     // right
                rect(ctx, cx - h, cy - g - s, cx - h + t, cy - g);     // top
                rect(ctx, cx - h, cy + g, cx - h + t, cy + g + s);     // bottom
            }
        }
    }
}
