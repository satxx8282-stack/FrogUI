package dev.blod.client.module.impl;

import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

/**
 * Look around freely in third person (default key V, hold).
 * The player's own yaw/pitch are never touched, so movement direction stays straight.
 * CameraMixin orbits the camera around the player using this module's yaw/pitch.
 */
public final class FreeLook extends Module {
    public final NumberSetting distance = add(new NumberSetting("Distance", 4.0, 1.0, 12.0, 0.5));

    private float yaw, pitch;

    @Override public boolean persistEnabled() { return false; }

    public FreeLook() {
        super("FreeLook", "Look around without turning your player.", Category.RENDER, GLFW.GLFW_KEY_V);
        bindMode.setValue("Hold");
    }

    @Override protected boolean canEnable() { return mc.player != null; }

    @Override
    protected void onEnable() {
        ClientPlayerEntity p = mc.player;
        yaw = p.getYaw();
        pitch = p.getPitch();
    }

    public void handleLook(double dx, double dy) {
        yaw += (float) dx * 0.15f;
        pitch = MathHelper.clamp(pitch + (float) dy * 0.15f, -90f, 90f);
    }

    public float getYaw() { return yaw; }
    public float getPitch() { return pitch; }
}
