package dev.blod.client.mixin;

import dev.blod.client.BlodClient;
import dev.blod.client.event.MouseButtonEvent;
import dev.blod.client.event.ScrollEvent;
import net.minecraft.client.Mouse;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Lets modules (Zoom, FreeCam) consume the mouse wheel when no screen is open. */
@Mixin(Mouse.class)
public abstract class MouseMixin {
    @Shadow @Final private MinecraftClient client;

    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true)
    private void blod$onScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        if (client.currentScreen != null || window != client.getWindow().getHandle()) return;
        ScrollEvent event = BlodClient.EVENT_BUS.post(new ScrollEvent(vertical));
        if (event.isCancelled()) ci.cancel();
    }

    @Inject(method = "onMouseButton", at = @At("HEAD"))
    private void blod$onButton(long window, int button, int action, int modifiers, CallbackInfo ci) {
        if (client.currentScreen != null || window != client.getWindow().getHandle()) return;
        BlodClient.EVENT_BUS.post(new MouseButtonEvent(button, action));
    }
}
