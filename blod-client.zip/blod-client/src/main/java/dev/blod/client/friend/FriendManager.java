package dev.blod.client.friend;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import dev.blod.client.BlodClient;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** Friends list (by player name, case-insensitive). Friends are skipped by KillAura and shown green. */
public final class FriendManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Set<String> FRIENDS = new TreeSet<>();

    private FriendManager() {}

    private static Path file() {
        return FabricLoader.getInstance().getGameDir().resolve("blodclient").resolve("friends.json");
    }

    public static boolean isFriend(String name) { return FRIENDS.contains(name.toLowerCase(Locale.ROOT)); }

    public static boolean isFriend(Entity e) {
        return e instanceof PlayerEntity p && isFriend(p.getName().getString());
    }

    public static boolean toggle(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        boolean added = FRIENDS.add(n);
        if (!added) FRIENDS.remove(n);
        save();
        return added;
    }

    public static boolean add(String name) { boolean r = FRIENDS.add(name.toLowerCase(Locale.ROOT)); save(); return r; }
    public static boolean remove(String name) { boolean r = FRIENDS.remove(name.toLowerCase(Locale.ROOT)); save(); return r; }
    public static Set<String> all() { return Collections.unmodifiableSet(FRIENDS); }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            List<String> list = GSON.fromJson(Files.readString(f), new TypeToken<List<String>>() {}.getType());
            FRIENDS.clear();
            if (list != null) FRIENDS.addAll(list);
        } catch (Exception e) {
            BlodClient.LOGGER.error("Could not load friends", e);
        }
    }

    public static void save() {
        try {
            Path f = file();
            Files.createDirectories(f.getParent());
            Files.writeString(f, GSON.toJson(new ArrayList<>(FRIENDS)));
        } catch (IOException e) {
            BlodClient.LOGGER.error("Could not save friends", e);
        }
    }
}
