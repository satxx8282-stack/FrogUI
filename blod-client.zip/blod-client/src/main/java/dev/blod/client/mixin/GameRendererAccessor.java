package dev.blod.client.mixin;

import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Lets Projection read the exact FOV the world is rendered with. */
@Mixin(GameRenderer.class)
public interface GameRendererAccessor {
    @Invoker("getFov") double blod$getFov(Camera camera, float tickDelta, boolean changingFov);
}
