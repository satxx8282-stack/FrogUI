package dev.blod.client.module.impl;

import dev.blod.client.event.Subscribe;
import dev.blod.client.event.TickEvent;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.BoolSetting;
import dev.blod.client.module.setting.NumberSetting;
import net.minecraft.block.Block;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Places a block under your feet while you move. Picks the first solid block in your hotbar. */
public final class Scaffold extends Module {
    private final NumberSetting expand = add(new NumberSetting("Expand", 0, 0, 6, 1));
    private final BoolSetting swing = add(new BoolSetting("Swing", true));
    private final BoolSetting restore = add(new BoolSetting("Restore Slot", true));

    private int prevSlot = -1;

    public Scaffold() {
        super("Scaffold", "Automatically places blocks under you.", Category.MOVEMENT, -1);
    }

    @Override
    protected void onDisable() {
        if (restore.get() && mc.player != null && prevSlot != -1) mc.player.getInventory().selectedSlot = prevSlot;
        prevSlot = -1;
    }

    @Subscribe
    public void onTick(TickEvent e) {
        ClientPlayerEntity p = mc.player;
        World world = mc.world;
        if (p == null || world == null || mc.interactionManager == null || mc.currentScreen != null) return;

        int slot = findBlockSlot(p);
        if (slot == -1) return;

        Vec3d v = p.getVelocity();
        BlockPos base = BlockPos.ofFloored(p.getX() + v.x * expand.get(), p.getY() - 1.0, p.getZ() + v.z * expand.get());
        if (!world.getBlockState(base).isReplaceable()) return;

        for (Direction d : Direction.values()) {
            BlockPos neighbour = base.offset(d);
            if (world.getBlockState(neighbour).isReplaceable()) continue;

            if (prevSlot == -1) prevSlot = p.getInventory().selectedSlot;
            p.getInventory().selectedSlot = slot;

            Direction face = d.getOpposite();                       // the neighbour's face that touches our target block
            Vec3d hitPos = Vec3d.ofCenter(neighbour).add(Vec3d.of(face.getVector()).multiply(0.5));
            mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, new BlockHitResult(hitPos, face, neighbour, false));
            if (swing.get()) p.swingHand(Hand.MAIN_HAND);
            return;
        }
    }

    private int findBlockSlot(ClientPlayerEntity p) {
        for (int i = 0; i < 9; i++) {
            ItemStack s = p.getInventory().getStack(i);
            if (s.isEmpty() || !(s.getItem() instanceof BlockItem bi)) continue;
            Block b = bi.getBlock();
            if (b.getDefaultState().isFullCube(mc.world, BlockPos.ORIGIN) && !(b instanceof net.minecraft.block.FallingBlock)
                    && !(b instanceof net.minecraft.block.BlockWithEntity)) return i;
        }
        return -1;
    }
}
