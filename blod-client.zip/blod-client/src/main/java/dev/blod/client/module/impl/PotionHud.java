package dev.blod.client.module.impl;

import dev.blod.client.event.Render2DEvent;
import dev.blod.client.event.Subscribe;
import dev.blod.client.gui.RenderUtil;
import dev.blod.client.gui.Theme;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;

/** Active potion effects with remaining time (left side, under the watermark). */
public final class PotionHud extends Module {
    public PotionHud() {
        super("PotionHud", "Lists your active potion effects.", Category.CLIENT, -1);
        setListed(false);
    }

    @Subscribe
    public void onRender2D(Render2DEvent e) {
        if (mc.player == null) return;
        DrawContext ctx = e.context();
        TextRenderer tr = mc.textRenderer;
        int y = 28;
        for (StatusEffectInstance fx : mc.player.getStatusEffects()) {
            String name = fx.getEffectType().value().getName().getString() + " " + roman(fx.getAmplifier() + 1);
            String time;
            int secs = fx.getDuration() / 20;
            if (fx.isInfinite()) time = "**:**";
            else time = String.format("%d:%02d", secs / 60, secs % 60);

            int w = RenderUtil.width(tr, name) + RenderUtil.width(tr, time) + 22;
            RenderUtil.roundedOutline(ctx, 6, y, w, 15, 4, Theme.alpha(Theme.DARK_RED, 190), Theme.alpha(Theme.BG, 210));
            RenderUtil.text(ctx, tr, name, 11, y + 4, Theme.TEXT, true);
            RenderUtil.text(ctx, tr, time, 11 + RenderUtil.width(tr, name) + 8, y + 4,
                    !fx.isInfinite() && secs < 10 ? Theme.BRIGHT_RED : Theme.TEXT_DIM, true);
            y += 17;
        }
    }

    private static String roman(int n) {
        return switch (n) { case 1 -> "I"; case 2 -> "II"; case 3 -> "III"; case 4 -> "IV"; case 5 -> "V"; default -> String.valueOf(n); };
    }
}
