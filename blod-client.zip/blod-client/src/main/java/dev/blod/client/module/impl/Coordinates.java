package dev.blod.client.module.impl;

import dev.blod.client.event.Render2DEvent;
import dev.blod.client.event.Subscribe;
import dev.blod.client.gui.RenderUtil;
import dev.blod.client.gui.Theme;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.BoolSetting;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.world.World;

/** Coordinates HUD (bottom-left) with optional Nether/Overworld conversion and facing. */
public final class Coordinates extends Module {
    private final BoolSetting converted = add(new BoolSetting("Nether Conversion", true));
    private final BoolSetting facing = add(new BoolSetting("Facing", true));

    public Coordinates() {
        super("Coordinates", "Shows your XYZ on screen.", Category.CLIENT, -1);
        setListed(false);
    }

    @Subscribe
    public void onRender2D(Render2DEvent e) {
        if (mc.player == null || mc.world == null) return;
        DrawContext ctx = e.context();
        TextRenderer tr = mc.textRenderer;

        String line = String.format("XYZ  %.1f  %.1f  %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
        if (facing.get()) line += "  |  " + mc.player.getHorizontalFacing().asString().toUpperCase();
        String second = null;
        if (converted.get()) {
            if (mc.world.getRegistryKey() == World.NETHER)
                second = String.format("Overworld  %.0f  %.0f", mc.player.getX() * 8, mc.player.getZ() * 8);
            else if (mc.world.getRegistryKey() == World.OVERWORLD)
                second = String.format("Nether  %.0f  %.0f", mc.player.getX() / 8, mc.player.getZ() / 8);
        }

        int w = Math.max(RenderUtil.width(tr, line), second == null ? 0 : RenderUtil.width(tr, second)) + 12;
        int h = second == null ? 16 : 27;
        int x = 6, y = ctx.getScaledWindowHeight() - h - 6;
        RenderUtil.roundedOutline(ctx, x, y, w, h, 4, Theme.alpha(Theme.DARK_RED, 200), Theme.alpha(Theme.BG, 215));
        ctx.fill(x + 1, y + 4, x + 3, y + h - 4, Theme.RED);
        RenderUtil.text(ctx, tr, line, x + 7, y + 4, Theme.TEXT, true);
        if (second != null) RenderUtil.text(ctx, tr, second, x + 7, y + 15, Theme.TEXT_DIM, true);
    }
}
