package dev.blod.client;

import dev.blod.client.command.CommandHandler;
import dev.blod.client.config.ConfigManager;
import dev.blod.client.event.EventBus;
import dev.blod.client.friend.FriendManager;
import dev.blod.client.event.Render2DEvent;
import dev.blod.client.event.TickEvent;
import dev.blod.client.module.Module;
import dev.blod.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Blod Client entrypoint: wires Fabric callbacks into our own event bus. */
public final class BlodClient implements ClientModInitializer {
    public static final String NAME = "Blod Client";
    public static final String VERSION = "0.1.0";
    public static final Logger LOGGER = LoggerFactory.getLogger("BlodClient");
    public static final EventBus EVENT_BUS = new EventBus();

    private static ModuleManager modules;

    public static ModuleManager modules() { return modules; }

    /** Null-safe module lookup (mixins can run before init finished). */
    public static <T extends Module> T module(Class<T> type) {
        return modules == null ? null : modules.get(type);
    }

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        modules.init();

        ClientTickEvents.END_CLIENT_TICK.register(client -> EVENT_BUS.post(new TickEvent()));
        HudRenderCallback.EVENT.register((ctx, tickCounter) ->
                EVENT_BUS.post(new Render2DEvent(ctx, tickCounter.getTickDelta(false))));

        // friends + last used config
        FriendManager.load();
        if (ConfigManager.exists("default")) ConfigManager.load("default");

        // ".command" chat commands never reach the server
        ClientSendMessageEvents.ALLOW_CHAT.register(message -> !CommandHandler.handle(message));

        // persist on exit
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            ConfigManager.save("default");
            FriendManager.save();
        });

        LOGGER.info("{} v{} initialised", NAME, VERSION);
    }
}
