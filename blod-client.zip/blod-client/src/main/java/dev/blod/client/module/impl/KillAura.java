package dev.blod.client.module.impl;

import dev.blod.client.event.Subscribe;
import dev.blod.client.event.TickEvent;
import dev.blod.client.friend.FriendManager;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.BoolSetting;
import dev.blod.client.module.setting.ModeSetting;
import dev.blod.client.module.setting.NumberSetting;
import dev.blod.client.util.Rotations;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.Comparator;
import java.util.Optional;
import java.util.stream.StreamSupport;

/** Automatically attacks nearby targets once your attack cooldown is ready. Friends are never attacked. */
public final class KillAura extends Module {
    private final NumberSetting range = add(new NumberSetting("Range", 4.2, 2.5, 6.0, 0.1));
    private final ModeSetting rotation = add(new ModeSetting("Rotation", "Smooth", "Smooth", "Snap", "None"));
    private final NumberSetting rotSpeed = add(new NumberSetting("Rotation Speed", 45, 5, 180, 5));
    private final ModeSetting priority = add(new ModeSetting("Priority", "Distance", "Distance", "Health"));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting hostile = add(new BoolSetting("Hostile Mobs", false));
    private final BoolSetting passive = add(new BoolSetting("Passive Mobs", false));
    private final BoolSetting throughWalls = add(new BoolSetting("Through Walls", false));
    private final BoolSetting weaponOnly = add(new BoolSetting("Weapon Only", false));

    private LivingEntity target;

    public KillAura() {
        super("KillAura", "Attacks entities around you automatically.", Category.COMBAT, GLFW.GLFW_KEY_R);
    }

    public LivingEntity getTarget() { return target; }

    @Override protected void onDisable() { target = null; }

    @Subscribe
    public void onTick(TickEvent e) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || !p.isAlive() || p.isSpectator() || mc.currentScreen != null) { target = null; return; }

        target = findTarget(p);
        if (target == null) return;

        Vec3d eye = p.getEyePos();
        Vec3d aim = Rotations.closestPoint(target.getBoundingBox(), eye);
        float[] want = Rotations.to(eye, aim);

        // ---- rotate ----
        if (rotation.is("Snap")) {
            p.setYaw(want[0]);
            p.setPitch(want[1]);
        } else if (rotation.is("Smooth")) {
            float s = rotSpeed.getFloat();
            p.setYaw(p.getYaw() + MathHelper.clamp(MathHelper.wrapDegrees(want[0] - p.getYaw()), -s, s));
            p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(want[1] - p.getPitch(), -s, s), -90f, 90f));
        }

        // ---- attack ----
        if (weaponOnly.get() && !holdingWeapon(p)) return;
        if (p.getAttackCooldownProgress(0.5f) < 0.95f) return;
        if (!rotation.is("None")) {
            float dy = Math.abs(MathHelper.wrapDegrees(want[0] - p.getYaw()));
            float dp = Math.abs(want[1] - p.getPitch());
            if (dy > 20f || dp > 20f) return;                      // not aimed yet
        }
        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);
    }

    private LivingEntity findTarget(ClientPlayerEntity p) {
        Vec3d eye = p.getEyePos();
        Comparator<LivingEntity> order = priority.is("Health")
                ? Comparator.comparingDouble(LivingEntity::getHealth)
                : Comparator.comparingDouble((LivingEntity le) -> eye.distanceTo(Rotations.closestPoint(le.getBoundingBox(), eye)));
        Optional<LivingEntity> best = StreamSupport.stream(mc.world.getEntities().spliterator(), false)
                .filter(en -> en instanceof LivingEntity && en != p && en.isAlive())
                .map(en -> (LivingEntity) en)
                .filter(this::validType)
                .filter(le -> eye.distanceTo(Rotations.closestPoint(le.getBoundingBox(), eye)) <= range.get())
                .filter(le -> throughWalls.get() || p.canSee(le))
                .min(order);
        return best.orElse(null);
    }

    private boolean validType(Entity en) {
        if (en instanceof PlayerEntity pl) return players.get() && !FriendManager.isFriend(pl) && !pl.isSpectator();
        if (en instanceof Monster) return hostile.get();
        if (en instanceof PassiveEntity) return passive.get();
        return false;
    }

    private boolean holdingWeapon(ClientPlayerEntity p) {
        ItemStack s = p.getMainHandStack();
        return s.isIn(ItemTags.SWORDS) || s.isIn(ItemTags.AXES);
    }
}
