package dev.blod.client.command;

import dev.blod.client.BlodClient;
import dev.blod.client.config.ConfigManager;
import dev.blod.client.friend.FriendManager;
import dev.blod.client.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.Arrays;
import java.util.Locale;

/**
 * Chat commands, prefix ".". They never reach the server.
 *   .help | .friend add|remove|list <name> | .config save|load|delete|list <name>
 *   .toggle <module> | .bind <module> <key|none> | .modules
 */
public final class CommandHandler {
    public static final String PREFIX = ".";

    private CommandHandler() {}

    /** @return true if the message was a Blod command (and must not be sent to the server). */
    public static boolean handle(String message) {
        if (!message.startsWith(PREFIX) || message.startsWith("..")) return false;
        String[] a = message.substring(1).trim().split("\\s+");
        if (a.length == 0 || a[0].isEmpty()) { help(); return true; }

        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "help" -> help();
            case "friend", "friends", "f" -> friend(a);
            case "config", "cfg" -> config(a);
            case "toggle", "t" -> {
                Module m = find(a, 1);
                if (m == null) break;
                if (!m.isToggleable()) { reply("Cannot toggle " + m.getName()); break; }
                m.toggle();
                reply(m.getName() + (m.isEnabled() ? " enabled" : " disabled"));
            }
            case "bind" -> bind(a);
            case "modules" -> reply(String.join(", ", BlodClient.modules().all().stream().map(Module::getName).toList()));
            default -> reply("Unknown command. Try .help");
        }
        return true;
    }

    private static void help() {
        reply("Commands:");
        reply(".friend add|remove|list <name>");
        reply(".config save|load|delete|list <name>");
        reply(".toggle <module>   .bind <module> <key|none>   .modules");
    }

    private static void friend(String[] a) {
        if (a.length < 2) { reply("Usage: .friend add|remove|list <name>"); return; }
        switch (a[1].toLowerCase(Locale.ROOT)) {
            case "add" -> { if (a.length > 2) reply(FriendManager.add(a[2]) ? "Added friend " + a[2] : a[2] + " is already a friend"); }
            case "remove", "del" -> { if (a.length > 2) reply(FriendManager.remove(a[2]) ? "Removed " + a[2] : a[2] + " is not a friend"); }
            case "list" -> reply(FriendManager.all().isEmpty() ? "No friends yet." : "Friends: " + String.join(", ", FriendManager.all()));
            default -> reply("Usage: .friend add|remove|list <name>");
        }
    }

    private static void config(String[] a) {
        if (a.length < 2) { reply("Usage: .config save|load|delete|list <name>"); return; }
        String sub = a[1].toLowerCase(Locale.ROOT);
        if (sub.equals("list")) { reply("Configs: " + (ConfigManager.list().isEmpty() ? "none" : String.join(", ", ConfigManager.list()))); return; }
        if (a.length < 3) { reply("Give a config name."); return; }
        switch (sub) {
            case "save" -> reply(ConfigManager.save(a[2]) ? "Saved config " + a[2] : "Could not save " + a[2]);
            case "load" -> reply(ConfigManager.load(a[2]) ? "Loaded config " + a[2] : "Config " + a[2] + " not found");
            case "delete" -> reply(ConfigManager.delete(a[2]) ? "Deleted " + a[2] : "Config " + a[2] + " not found");
            default -> reply("Usage: .config save|load|delete|list <name>");
        }
    }

    private static void bind(String[] a) {
        Module m = find(a, 1);
        if (m == null) return;
        if (a.length < 3) { reply(m.getName() + " is bound to " + m.getKeyName()); return; }
        if (a[2].equalsIgnoreCase("none")) { m.setKey(-1); reply("Unbound " + m.getName()); return; }
        try {
            InputUtil.Key key = InputUtil.fromTranslationKey("key.keyboard." + a[2].toLowerCase(Locale.ROOT));
            m.setKey(key.getCode());
            reply(m.getName() + " bound to " + m.getKeyName());
        } catch (Exception e) {
            reply("Unknown key \"" + a[2] + "\" (examples: x, z, f4, right.shift)");
        }
    }

    private static Module find(String[] a, int idx) {
        if (a.length <= idx) { reply("Give a module name."); return null; }
        String name = String.join("", Arrays.copyOfRange(a, idx, idx + 1));
        for (Module m : BlodClient.modules().all()) if (m.getName().equalsIgnoreCase(name)) return m;
        reply("No module called " + name);
        return null;
    }

    public static void reply(String msg) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.inGameHud == null) return;
        mc.inGameHud.getChatHud().addMessage(Text.literal("[Blod] ").formatted(Formatting.RED)
                .append(Text.literal(msg).formatted(Formatting.GRAY)));
    }
}
