package dev.blod.client.module;

import dev.blod.client.BlodClient;
import dev.blod.client.event.KeyEvent;
import dev.blod.client.event.Subscribe;
import dev.blod.client.module.impl.*;
import net.minecraft.client.MinecraftClient;

import java.util.*;

/** Owns every module instance and routes keybinds to them. */
public final class ModuleManager {
    private final Map<Class<? extends Module>, Module> modules = new LinkedHashMap<>();

    public void init() {
        // Client
        register(new NavigatorModule());
        register(new ClientSettings());
        register(new ArrayListModule());
        register(new WatermarkModule());
        register(new NotificationsModule());
        register(new Coordinates());
        register(new ArmorHud());
        register(new PotionHud());
        register(new TargetHud());
        register(new CapeModule());
        // Combat
        register(new KillAura());
        register(new AutoClicker());
        register(new Criticals());
        register(new Velocity());
        register(new AutoArmor());
        register(new AutoPot());
        register(new AutoGapple());
        register(new Reach());
        register(new Hitbox());
        // Movement
        register(new Sprint());
        register(new Speed());
        register(new Flight());
        register(new NoSlow());
        register(new Scaffold());
        register(new Jesus());
        register(new Step());
        register(new LongJump());
        // Render
        register(new FreeCam());
        register(new Zoom());
        register(new FreeLook());
        register(new Fullbright());
        register(new ESP());
        register(new Nametags());
        register(new Tracers());
        register(new NoRender());
        register(new ChinaHat());
        register(new TargetESP());
        register(new ViewModel());
        register(new CrosshairModule());
        // Player
        register(new AutoTool());
        register(new FastPlace());
        register(new NoFall());
        register(new InventoryMove());
        register(new MiddleClickFriend());
        register(new FakePlayer());

        // Default-on (HUD) modules; a saved "default" config can override this later.
        List<Class<? extends Module>> defaults = List.of(ArrayListModule.class, WatermarkModule.class, NotificationsModule.class,
                Coordinates.class, ArmorHud.class, PotionHud.class, TargetHud.class);
        for (Class<? extends Module> c : defaults) get(c).setEnabled(true);

        BlodClient.EVENT_BUS.register(this);
        BlodClient.LOGGER.info("Loaded {} modules", modules.size());
    }

    private void register(Module m) { modules.put(m.getClass(), m); }

    public <T extends Module> T get(Class<T> type) { return type.cast(modules.get(type)); }
    public Collection<Module> all() { return modules.values(); }

    public List<Module> byCategory(Category c) {
        return modules.values().stream().filter(m -> m.getCategory() == c).toList();
    }

    /** Keybind dispatcher. Presses are ignored while any screen is open; releases always count (Hold mode). */
    @Subscribe
    public void onKey(KeyEvent e) {
        boolean screenOpen = MinecraftClient.getInstance().currentScreen != null;
        for (Module m : modules.values()) {
            if (m.getKey() != e.key()) continue;
            if (e.action() == 1 && !screenOpen) m.onBindPress(true);
            else if (e.action() == 0 && m.bindMode.is("Hold")) m.onBindPress(false);
        }
    }
}
