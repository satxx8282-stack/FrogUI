package dev.blod.client.gui;

import dev.blod.client.mixin.GameRendererAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * World -> screen projection for the 2D HUD (ESP boxes, tracers, nametags, hats).
 * Uses the live camera rotation and the exact FOV the world is rendered with (so Zoom is respected).
 */
public final class Projection {
    private Projection() {}

    /** Returns {x, y} in scaled GUI coordinates, or null when the point is behind the camera. */
    public static double[] project(Vec3d world, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        Camera cam = mc.gameRenderer.getCamera();
        Vec3d cp = cam.getPos();

        Vector3f v = new Vector3f((float) (world.x - cp.x), (float) (world.y - cp.y), (float) (world.z - cp.z));
        new Quaternionf(cam.getRotation()).conjugate().transform(v);
        if (v.z > -0.05f) return null;                      // behind the camera (camera looks along -Z)

        double fov = Math.toRadians(((GameRendererAccessor) mc.gameRenderer).blod$getFov(cam, tickDelta, true));
        double t = Math.tan(fov / 2.0);
        double aspect = (double) mc.getWindow().getFramebufferWidth() / mc.getWindow().getFramebufferHeight();

        double ndcX = (v.x / -v.z) / (t * aspect);
        double ndcY = (v.y / -v.z) / t;
        return new double[]{
                (ndcX * 0.5 + 0.5) * mc.getWindow().getScaledWidth(),
                (0.5 - ndcY * 0.5) * mc.getWindow().getScaledHeight()
        };
    }

    /** Screen-space bounding rectangle {minX, minY, maxX, maxY} of a box, or null if any corner is behind the camera. */
    public static double[] projectBox(Box b, float tickDelta) {
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i < 8; i++) {
            Vec3d c = new Vec3d((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ);
            double[] p = project(c, tickDelta);
            if (p == null) return null;
            minX = Math.min(minX, p[0]); minY = Math.min(minY, p[1]);
            maxX = Math.max(maxX, p[0]); maxY = Math.max(maxY, p[1]);
        }
        return new double[]{minX, minY, maxX, maxY};
    }
}
