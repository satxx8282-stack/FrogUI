package dev.blod.client.gui;

import dev.blod.client.BlodClient;
import dev.blod.client.module.impl.ClientSettings;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** 2D drawing helpers built on DrawContext (rounded rectangles etc.). */
public final class RenderUtil {
    private RenderUtil() {}

    /** Filled rounded rectangle, drawn as horizontal strips. */
    public static void roundedRect(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { ctx.fill(x, y, x + w, y + h, color); return; }
        ctx.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            ctx.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            ctx.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
    }

    /** Rounded rectangle with a 1px border. */
    public static void roundedOutline(DrawContext ctx, int x, int y, int w, int h, int r, int border, int fill) {
        roundedRect(ctx, x, y, w, h, r, border);
        roundedRect(ctx, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), fill);
    }

    public static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    // ------------------------------------------------------------------ custom font

    /** Font defined in assets/blodclient/font/blod.json (Poppins). */
    public static final Identifier FONT_ID = Identifier.of("blodclient", "blod");

    private static boolean customFont() {
        ClientSettings cs = BlodClient.module(ClientSettings.class);
        return cs == null || cs.customFont.get();
    }

    private static Text styled(String s) {
        return customFont() ? Text.literal(s).setStyle(Style.EMPTY.withFont(FONT_ID)) : Text.literal(s);
    }

    private static Text styled(Text t) {
        return customFont() ? t.copy().styled(st -> st.withFont(FONT_ID)) : t;
    }

    public static int text(DrawContext ctx, TextRenderer tr, String s, int x, int y, int color, boolean shadow) {
        return ctx.drawText(tr, styled(s), x, y, color, shadow);
    }

    public static int text(DrawContext ctx, TextRenderer tr, Text t, int x, int y, int color, boolean shadow) {
        return ctx.drawText(tr, styled(t), x, y, color, shadow);
    }

    public static int width(TextRenderer tr, String s) { return tr.getWidth(styled(s)); }
    public static int width(TextRenderer tr, Text t) { return tr.getWidth(styled(t)); }

    // ------------------------------------------------------------------ lines

    /** 1px line (DrawContext has no line primitive, so it is stepped with small squares). */
    public static void line(DrawContext ctx, double x1, double y1, double x2, double y2, int color) {
        double dx = x2 - x1, dy = y2 - y1;
        int steps = (int) Math.min(2500, Math.max(Math.abs(dx), Math.abs(dy)));
        if (steps == 0) { ctx.fill((int) x1, (int) y1, (int) x1 + 1, (int) y1 + 1, color); return; }
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        for (int i = 0; i <= steps; i++) {
            int x = (int) (x1 + dx * i / steps), y = (int) (y1 + dy * i / steps);
            if (x < -1 || y < -1 || x > w || y > h) continue;
            ctx.fill(x, y, x + 1, y + 1, color);
        }
    }
}
