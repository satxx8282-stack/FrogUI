package dev.blod.client.module.impl;

import dev.blod.client.event.Render2DEvent;
import dev.blod.client.event.Subscribe;
import dev.blod.client.friend.FriendManager;
import dev.blod.client.gui.Projection;
import dev.blod.client.gui.RenderUtil;
import dev.blod.client.module.Category;
import dev.blod.client.module.Module;
import dev.blod.client.module.setting.BoolSetting;
import dev.blod.client.module.setting.ModeSetting;
import dev.blod.client.module.setting.NumberSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Lines from the bottom (or centre) of the screen to entities. */
public final class Tracers extends Module {
    private final ModeSetting origin = add(new ModeSetting("Origin", "Bottom", "Bottom", "Center"));
    private final BoolSetting players = add(new BoolSetting("Players", true));
    private final BoolSetting hostile = add(new BoolSetting("Hostile Mobs", false));
    private final NumberSetting maxDist = add(new NumberSetting("Max Distance", 128, 16, 256, 8));

    public Tracers() {
        super("Tracers", "Draws lines to entities.", Category.RENDER, -1);
    }

    @Subscribe
    public void onRender2D(Render2DEvent ev) {
        if (mc.world == null || mc.player == null) return;
        int sw = ev.context().getScaledWindowWidth(), sh = ev.context().getScaledWindowHeight();
        double ox = sw / 2.0, oy = origin.is("Bottom") ? sh : sh / 2.0;

        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || mc.player.distanceTo(e) > maxDist.get()) continue;
            boolean ok = (e instanceof PlayerEntity && players.get()) || (e instanceof Monster && hostile.get());
            if (!ok) continue;

            Vec3d feet = e.getLerpedPos(ev.tickDelta()).add(0, e.getHeight() * 0.5, 0);
            double[] p = Projection.project(feet, ev.tickDelta());
            if (p == null) continue;

            int color = FriendManager.isFriend(e) ? 0xFF55FF55 : (e instanceof PlayerEntity ? 0xFFC41E3A : 0xFF8B0000);
            RenderUtil.line(ev.context(), ox, oy, p[0], p[1], color);
        }
    }
}
